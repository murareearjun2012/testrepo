from django.contrib import admin
from blog.models import UserProfileInfo, Blog, Comment

# Register your models here.
""" Registering the models so that can be accessed from admin page"""
admin.site.register(UserProfileInfo)
admin.site.register(Blog)
admin.site.register(Comment)
