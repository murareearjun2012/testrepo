from django import forms
from django.contrib.auth.models import User
from blog.models import UserProfileInfo
from blog.models import Blog,Comment

class UserForm(forms.ModelForm):
    """ Form for the builtin model User"""
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta():
        model = User
        fields = ('id','username','email','password')
        widgets = {
            'username' : forms.TextInput(attrs={'class':'form-control'}),
            'email' : forms.TextInput(attrs={'class':'form-control'}),
            'password' : forms.PasswordInput(attrs={'class':'form-control'}),
        }



class UserProfileInfoForm(forms.ModelForm):
    """Form for Custom fields in the User model """
    class Meta():
        model = UserProfileInfo
        fields = ('name','mobile')
        widgets = {
            'name' : forms.TextInput(attrs={'class':'form-control'}),
            'mobile' : forms.TextInput(attrs={'class':'form-control'}),
        }

class BlogForm(forms.ModelForm):
    """Form for creating a new Blog """
    class Meta:
        model = Blog
        fields = ('name','content')
        widgets = {
            'title' : forms.TextInput(attrs={'class':'form-control'}),
            'content' : forms.Textarea(attrs={
                'class': 'form-control',
                'rows': '4',
                'cols':4
            })
        }

class BlogEditForm(forms.ModelForm):
    """Form for editing an existing Blog """
    class Meta:
        model = Blog
        fields = ('name','content')
        widgets = {
            'title' : forms.TextInput(attrs={'class':'form-control'}),
            'content' : forms.Textarea(attrs={
                'class': 'form-control',
                'rows': '4',
                'cols':4
            })
        }

class CommentForm(forms.ModelForm):
    """ Form for creating comments"""
    content = forms.CharField(widget=forms.Textarea(attrs={
        'class': 'form-control',
        'placeholder': 'Type your comments...',
        'rows': '4'
    }))
    class Meta:
        model = Comment
        fields = ('content',)
