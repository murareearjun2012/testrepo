from django.db import models
from django.contrib.auth.models import User
from phonenumber_field.modelfields import PhoneNumberField
from django.urls import reverse


# Create your models here.
class UserProfileInfo(models.Model):
    """User Model that will create a new user"""
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    """Adding custom fields to the model User """
    name = models.CharField(max_length=255, null=True)
    mobile = PhoneNumberField(null=True)
    usr_created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.user.username


class Blog(models.Model):
    """  Blogs Model"""
    name = models.CharField(max_length=100)
    comment_count = models.IntegerField(null=True, blank=True)
    content = models.TextField()
    likes  =  models.ManyToManyField(User, related_name='likes', blank=True)
    dislikes  =  models.ManyToManyField(User, related_name='dislikes', blank=True)
    author =  models.ForeignKey(User, related_name='blog', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    """ String representation of the Blogname"""
    def __str__(self):
        return self.name

    """return the total likes count"""
    def total_likes(self):
        return self.likes.count()

    """return the total dislikes count """
    def total_dislikes(self):
        return self.dislikes.count()

    """ Return a absolute url path """
    def get_absolute_url(self):
        # return(f"blogs/{self.id}")
        return reverse('blog:blog_details', args=[self.id])


class Comment(models.Model):
    """Comments Model """
    blog = models.ForeignKey(Blog, related_name='comments_blog', on_delete=models.CASCADE)
    user = models.ForeignKey(User, related_name='comments_user', on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    """String representation of the blog name mapped to a particular blog and user"""
    def __str__(self):
        # return self.user.username
        return self.blog.name
