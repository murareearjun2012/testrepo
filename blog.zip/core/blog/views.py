from django.shortcuts import render,get_object_or_404, redirect
from django.contrib.auth.models import User
import datetime
import django
from django.db.models import F
from django.urls import reverse
from django.http import HttpResponseRedirect,HttpResponse, JsonResponse, Http404
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.decorators import login_required
from django.views.generic import View, ListView, DetailView, CreateView, UpdateView, DeleteView
from django.template.loader import render_to_string
from blog.forms import UserProfileInfoForm,UserForm, BlogForm,BlogEditForm, CommentForm
from blog.models import Blog, Comment

# Create your views here.
def blogs_list(request):
    """ contains all the blogs list """
    blog = Blog.objects.all()
    users = User.objects.all()

    context = {
      'blogs':blog,
      'users':users
    }
    return render(request,'blog/blogs.html', context)


def blogs_list_author(request,id):
    """ Particular Authors top commented blog"""
    blog = Comment.objects.filter(user_id=id).order_by('-updated_at')
    context = {
      'blog':blog,
    }
    return render(request,'blog/author_comment.html', context)


def blog_details(request, id):
    """Contains the blog details where CRUD, like , dislike and commenting happens"""
    blog = get_object_or_404(Blog, id=id)
    comments = Comment.objects.filter(blog=blog).order_by('-id')

##specific cmments history on details###
    comments_specific = Comment.objects.filter(blog=id, user_id= request.user.id).order_by('-id')

    is_liked = False
    if(blog.likes.filter(id=request.user.id).exists()):
        is_liked = True

    is_disliked = False
    if(blog.dislikes.filter(id=request.user.id).exists()):
        is_disliked = True

    if request.method=="POST":
        comment_form = CommentForm(request.POST or None)
        if comment_form.is_valid():
            content=request.POST.get('content')
            comment =Comment.objects.create(blog=blog, user=request.user, content=content)
            comment.save()

            cmt_cnt = Comment.objects.filter(blog=blog).count()
            Blog.objects.filter(id=id).update(comment_count=cmt_cnt)

            return HttpResponseRedirect(blog.get_absolute_url())
    else:
        comment_form = CommentForm()


    context = { 'blog':blog,'is_liked':is_liked,
        'total_likes':blog.total_likes(),
        'comments':comments,'comment_form':comment_form,
         'is_disliked':is_disliked, 'total_dislikes':blog.total_dislikes(),
         'comments_specific':comments_specific,
        }
    return render(request, 'blog/blog_details.html', context)


def like_post(request):
    """Code for like button"""
    blog = get_object_or_404(Blog, id=request.POST.get('id'))
    is_liked = False
##### Changing time ############
    if blog:
        Blog.objects.filter(id=request.POST.get('id')).update(updated_at=django.utils.timezone.now())

    if(blog.likes.filter(id=request.user.id).exists()):
        blog.likes.remove(request.user)
        is_liked = False

    else:
        blog.likes.add(request.user)
        is_liked = True


    context = { 'blog':blog,'is_liked':is_liked,
            'total_likes':blog.total_likes()}
    if request.is_ajax():
        html = render_to_string('blog/likes.html', context, request=request)
        return JsonResponse({'form':html})

def dislike_post(request):
    """Code for dislike button """
    blog = get_object_or_404(Blog, id=request.POST.get('id'))
    is_disliked = False

    if blog:
        Blog.objects.filter(id=request.POST.get('id')).update(updated_at=django.utils.timezone.now())

    if(blog.dislikes.filter(id=request.user.id).exists()):
        blog.dislikes.remove(request.user)
        is_disliked = False
    else:
        blog.dislikes.add(request.user)
        is_disliked = True

    context = { 'blog':blog,'is_disliked':is_disliked,
            'total_dislikes':blog.total_dislikes()}
    if request.is_ajax():
        html2 = render_to_string('blog/dislikes.html', context, request=request)
        return JsonResponse({'form':html2})


def blog_create(request):
    """Code for creating a new blog"""
    if request.method=='POST':
        form = BlogForm(request.POST)
        if form.is_valid():
            blog =  form.save(commit=False)
            blog.author = request.user
            blog.save()
            return HttpResponseRedirect(blog.get_absolute_url())
    form = BlogForm()
    context = {'form':form}
    return render(request, 'blog/blog_create.html', context)


def blog_edit(request, id):
    """ Editing an existing blog"""
    blog = get_object_or_404(Blog, id=id)
    if blog.author!=request.user:
        raise Http404()
    if request.method == 'POST':
        form = BlogEditForm(request.POST or None, instance=blog)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(blog.get_absolute_url())
    else:
        form = BlogEditForm(instance=blog)
    context = {
        'form':form,
        'blog':blog
    }
    return render(request, 'blog/blog_edit.html', context)


def blog_delete(request, id):
    """ Deleting a blog"""
    blog = get_object_or_404(Blog, id=id)
    if(request.user != blog.author):
        raise Http404()
    blog.delete()
    return redirect('blogs/')


def recent_liked(request):
    """ Recently liked blogs by a particular user"""
    blogs = Blog.objects.filter(author_id=request.user.id).order_by('-updated_at')
    comments = Comment.objects.filter(blog=blogs)

    ls = []
    for i in blogs:
        if(i.likes.count()!=0 and len(ls)<6):
            ls.append(i)
    context = {
        'blogs':ls,
        'comments':comments,
    }
    return render(request,'blog/recent_liked.html', context)


def author_created_or_commented(request):
    """ Author has created or commented a blog"""
    blog = Blog.objects.filter(author_id=request.user.id)
    comments = Comment.objects.filter(user_id=request.user.id)
    context = {
        'blog':blog,
        'comments':comments,
    }
    return render(request,'blog/author_created_or_commented.html', context)


def comment_history(request,id):
    """A particular authors comment history"""
    blog = get_object_or_404(Blog, id=id)
    comments_specific = Comment.objects.filter(blog=id, user_id= request.user.id).order_by('-updated_at')
    context = {
        'comments_specific':comments_specific,
    }
    return render(request,'blog/comment_history.html', context)


def blogs_untouched(request):
    """No changes has been made to the blog after creation """
    blog = Blog.objects.filter(author_id=request.user.id)
    unchanged = []
    for i in blog:
        change = (i.updated_at-i.created_at).total_seconds()
        if(change<1):
            unchanged.append(i)
    context = {
        'unchanged':unchanged,
    }
    return render(request,'blog/blogs_untouched.html', context)


def last3days(request):
    """ Count of likes and dislikes in the last three days """
    from_date = datetime.datetime.now() - datetime.timedelta(days=3)

    liked_post = Blog.objects.filter(created_at__range=[from_date, datetime.datetime.now()]) \
    .values('created_at','name','content', 'likes', 'dislikes').order_by('-likes')[:5]

    dislike_posts = Blog.objects.filter(updated_at__range=[from_date, datetime.datetime.now()]) \
        .values('created_at','name','content', 'likes', 'dislikes').order_by('-dislikes')[:5]

    context = {
        'liked_post':liked_post,
        'dislike_posts':dislike_posts
    }
    return render(request, 'blog/last3days.html', context)


def top5(request):
    """ Top 5 Commented blocks of the user """
    blog = Blog.objects.filter(author_id=request.user.id).order_by('-comment_count')[:5]
    comments = Comment.objects.filter(blog=blog).order_by('-id')

    context = {
        'blog':blog,
        'comments':comments,
    }
    return render(request, 'blog/top5.html', context)


def specific_user(request):
    """My Blog, contains all the data of a user """
    blog = Blog.objects.filter(author_id=request.user.id)
    comments = Comment.objects.filter(blog=blog).order_by('-id')

    context = {
        'blog':blog,
        'comments':comments,
    }
    return render(request,'blog/specific_user.html', context)


# Create your views here.
def index(request):
    """Home page """
    return render(request,"blog/index.html")

def base(request):
    """setting up the base html page """
    return render(request,"blog/base.html")

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('blog:blogs'))


def register(request):
    """Registering a new user into the database """
    registered = False
    if request.method == "POST":
        user_form = UserForm(data=request.POST)
        profile_form = UserProfileInfoForm(data=request.POST)

        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()

            profile = profile_form.save(commit=False)
            profile.user =  user

            profile.save()
            registered=True
        else :
            print(user_form.errors,profile_form.errors)
    else:
        user_form = UserForm()
        profile_form =UserProfileInfoForm()
    return render(request,'blog/registration.html',{'user_form':user_form,'profile_form':profile_form,'registered':registered})


def user_login(request):
    """ Login for a user"""
    login_success = False
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user =  authenticate(username=username,password=password)

        if user:
            if user.is_active:
                login(request,user)
                login_success = True
                return HttpResponseRedirect(reverse('blog:blogs'))

            else:
                return HttpResponse("Inactive Active")
        else:
            print("someone tried to login and failed")
            print("Username {} and Password {}".format(username,password))
            return HttpResponse("Invalid login details supplied")
    else:
        return render(request,'blog/login.html')
