from django.urls import path
from blog import views
from blog.views import (blogs_list, blog_details,blog_create,like_post,
        dislike_post,specific_user,top5,last3days,author_created_or_commented, recent_liked,
        blogs_list_author, blog_edit, blog_delete, blogs_untouched, comment_history)


app_name = 'blog'

urlpatterns = [
    path("",views.index,name="index"),      #home page
    path("base/",views.base,name="base"),   #base html page
    path("register/",views.register,name="register"),    #registering a new user
    path("login/",views.user_login,name="user_login"),   #login of the user
    path("logout/",views.user_logout,name="logout_user"),    #logout of the user
    path('blogs/',blogs_list, name="blogs" ),    #blogs list
    path('blogs/<int:id>', blog_details, name="blog_details"),  #blog details, contains CRUD, likes, dislikes and comments
    path('blogs/blog_create/', blog_create, name="blog_create"),     #creating a new blog
    path('blogs/blog_edit/<int:id>', blog_edit, name="blog_edit"),   #Editing an existing blog
    path('<int:id>', blog_delete, name="blog_delete"),   #deleling a blog
    path('likes/', like_post, name="like_post"),    #contains the likes path
    path('dislikes/', dislike_post, name="dislike_post"), #contains the dislikes path
    path('specific_user/', specific_user, name="specific_user"),    #contains the user specific data, my blogs
    path('blogs_untouched/', blogs_untouched, name="blogs_untouched"),  #Blogs that are created but never commented, like or disliked
    path('top5/', top5, name="top5"),   #Top 5 commented blogs of the user
    path('last3days/', last3days, name="last3days"), #Top 5 liked and disliked blogs overall
    path('author/', author_created_or_commented, name="author_created_or_commented"),   #particular loggedin author that has created or commented
    path('recent_liked/', recent_liked, name="recent_liked"),   #user has ecently liked blogs
    path('author_wise/<int:id>', blogs_list_author, name="blogs_list_author"),  #Displaying the comments author wise
    path('comment_history/<int:id>', comment_history, name="comment_history"),  #Comment history of a particular blog
]
