import os
import random
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from faker import Faker
from blog.models import Blog
from django.contrib.auth.models import User
from django.utils import timezone

def create_post(N):
    fake = Faker()
    for _ in range(N):
        id = random.randint(1,2)
        name = fake.name()
        content = fake.text()
        Blog.objects.create(name=name,
        content= content,
        author = User.objects.get(id=id),
        created_at = timezone.now(),
        updated_at = timezone.now())


create_post(10)
print("Data is create successfully")
